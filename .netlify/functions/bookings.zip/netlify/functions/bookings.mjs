
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/bookings.mjs
import { getStore } from "@netlify/blobs";
var STATUSES = /* @__PURE__ */ new Set(["new", "called", "done", "cancelled"]);
var PREFIX = "booking/";
function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" }
  });
}
function clip(value, max) {
  return String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
}
function store() {
  return getStore("hana-bookings");
}
function bookingKey(code) {
  return `${PREFIX}${code}`;
}
function deletedKey(code) {
  return `deleted/${code}`;
}
function authorized(request) {
  const expected = process.env.ADMIN_PASSWORD || "";
  if (!expected) return false;
  const header = request.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (token.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < token.length; i += 1) diff |= token.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}
var TOURS = {
  "hanoi-night-food-street": { price: 68e4, weekend: false, name: "H\xE0 N\u1ED9i \u0110\xEAm & H\u01B0\u01A1ng V\u1ECB \u1EA8m Th\u1EF1c Ph\u1ED1 C\u1ED5" },
  "hanoi-night-long-bien-bridge": { price: 55e4, weekend: false, name: "C\u1EA7u Long Bi\xEAn Ho\xE0ng H\xF4n & K\xFD \u1EE8c \u0110\xEAm S\xF4ng H\u1ED3ng" },
  "hanoi-express-egg-coffee-workshop": { price: 45e4, weekend: false, name: "Tinh Hoa C\xE0 Ph\xEA Tr\u1EE9ng & Ng\xF5 Nh\u1ECF Ph\u1ED1 C\u1ED5" },
  "hanoi-express-cyclo-heritage": { price: 42e4, weekend: false, name: "Th\u1EA3nh Th\u01A1i X\xEDch L\xF4 36 Ph\u1ED1 Ph\u01B0\u1EDDng" },
  "hanoi-halfday-heritage-temple-hoangthanh": { price: 79e4, weekend: false, name: "D\u1EA5u \u1EA4n Ho\xE0ng Th\xE0nh & V\u0103n Mi\u1EBFu Qu\u1ED1c T\u1EED Gi\xE1m" },
  "hanoi-halfday-west-lake-zen": { price: 72e4, weekend: false, name: "H\u1ED3 T\xE2y L\u1ED9ng Gi\xF3, Ch\xF9a Tr\u1EA5n Qu\u1ED1c & Tr\xE0 Sen Qu\xFD" },
  "hanoi-fullday-signature-thousand-years": { price: 135e4, weekend: false, name: "H\xE0 N\u1ED9i Tr\u1ECDn V\u1EB9n: Di S\u1EA3n 1000 N\u0103m V\u0103n Hi\u1EBFn" },
  "hanoi-weekend-duong-lam-ancient-village": { price: 115e4, weekend: true, name: "Cu\u1ED1i Tu\u1EA7n B\xECnh Y\xEAn: L\xE0ng C\u1ED5 \u0110\u01B0\u1EDDng L\xE2m & \u0110\u1EA5t Hai Vua" },
  "hanoi-weekend-ba-vi-mountain-fresh": { price: 125e4, weekend: true, name: "Cu\u1ED1i Tu\u1EA7n Xanh: V\u01B0\u1EDDn Qu\u1ED1c Gia Ba V\xEC & R\u1EEBng Th\xF4ng M\xE2y" }
};
function hanoiToday(now) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Ho_Chi_Minh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(now);
  const value = (type) => parts.find((part) => part.type === type).value;
  return `${value("year")}-${value("month")}-${value("day")}`;
}
function dayAfter(iso) {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day + 1)).toISOString().slice(0, 10);
}
function realDate(iso) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function wholeNumber(value, min, max) {
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(number) || number < min || number > max) return null;
  return number;
}
function quoteTour(tour, adults, children, pickup, photo, percent) {
  const childPrice = Math.round(tour.price * 0.7);
  const addOn = (photo ? 35e4 : 0) + (pickup === "hotel" ? 1e5 : 0);
  const subtotal = adults * tour.price + children * childPrice + addOn;
  const total = Math.max(0, subtotal - Math.round(subtotal * percent / 100));
  const deposit = Math.round(total * 0.3 / 1e3) * 1e3;
  return { total, deposit, balance: total - deposit };
}
function assessBooking(input, now = /* @__PURE__ */ new Date()) {
  if (!input || typeof input !== "object") return null;
  const bookingCode = clip(input.bookingCode, 16).toUpperCase();
  const phoneDigits = String(input.phone ?? "").replace(/\D/g, "");
  const email = clip(input.email, 120);
  const date = clip(input.date, 10);
  const adults = wholeNumber(input.adults, 1, 30);
  const children = wholeNumber(input.children, 0, 30);
  const tour = TOURS[clip(input.tourId, 80)];
  const pickup = input.pickup === "hotel" ? "hotel" : input.pickup === "meeting" ? "meeting" : "";
  const hotel = clip(input.hotel, 120);
  if (!/^HE-\d{6}$/.test(bookingCode)) return null;
  if (clip(input.fullName, 80).length < 2) return null;
  if (phoneDigits.length < 8 || phoneDigits.length > 15) return null;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  if (!realDate(date) || date < dayAfter(hanoiToday(now))) return null;
  if (!tour || adults === null || children === null || !pickup) return null;
  if (tour.weekend && ![0, 6].includes((/* @__PURE__ */ new Date(`${date}T00:00:00Z`)).getUTCDay())) return null;
  if (pickup === "hotel" && hotel.length < 2) return null;
  const photo = input.photo === true;
  const quotes = [0, 5, 10].map((percent) => quoteTour(tour, adults, children, pickup, photo, percent));
  const matched = quotes.find((item) => item.total === Number(input.total) && item.deposit === Number(input.deposit) && item.balance === Number(input.balance));
  if (!matched) return null;
  return {
    bookingCode,
    tourId: clip(input.tourId, 80),
    tourName: tour.name,
    date,
    adults,
    children,
    pickup,
    photo,
    fullName: clip(input.fullName, 80),
    phone: clip(phoneDigits, 20),
    email,
    hotel,
    notes: clip(input.notes, 400),
    total: matched.total,
    deposit: matched.deposit,
    balance: matched.balance,
    createdAt: clip(input.createdAt, 40) || now.toISOString(),
    status: "new"
  };
}
function sameBooking(existing, record) {
  const fields = ["tourId", "tourName", "date", "adults", "children", "pickup", "photo", "fullName", "phone", "email", "hotel", "notes", "total", "deposit", "balance"];
  return fields.every((field) => existing[field] === record[field]);
}
async function migrateLegacy(blobs) {
  const legacy = await blobs.get("items", { type: "json" });
  if (!Array.isArray(legacy)) return;
  for (const item of legacy) {
    if (!item || typeof item.bookingCode !== "string") continue;
    const key = bookingKey(item.bookingCode.toUpperCase());
    const existing = await blobs.get(key, { type: "json" });
    if (!existing) await blobs.setJSON(key, item);
  }
  await blobs.delete("items");
}
async function readSubscribers(blobs) {
  const listed = await blobs.list({ prefix: "subscriber/" });
  const items = [];
  for (const blob of listed.blobs || []) {
    const item = await blobs.get(blob.key, { type: "json" });
    if (item && item.email) items.push(item);
  }
  items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  return items;
}
function removedBooking(item) {
  return Boolean(item && (item.status === "deleted" || item.deletedAt));
}
async function readJSON(blobs, key) {
  try {
    return await blobs.get(key, { type: "json", consistency: "strong" });
  } catch (error) {
    if (error?.name !== "BlobsConsistencyError") throw error;
    return blobs.get(key, { type: "json" });
  }
}
async function readRecord(blobs, key) {
  try {
    return await blobs.getWithMetadata(key, { type: "json", consistency: "strong" });
  } catch (error) {
    if (error?.name !== "BlobsConsistencyError") throw error;
    const data = await blobs.get(key, { type: "json" });
    return data ? { data, etag: void 0, metadata: {} } : null;
  }
}
async function readItems(blobs) {
  await migrateLegacy(blobs);
  const [listed, removed] = await Promise.all([
    blobs.list({ prefix: PREFIX }),
    blobs.list({ prefix: "deleted/" })
  ]);
  const removedCodes = new Set((removed.blobs || []).map((blob) => blob.key.slice("deleted/".length).toUpperCase()));
  const items = [];
  for (const blob of listed.blobs || []) {
    const item = await blobs.get(blob.key, { type: "json" });
    const code = item?.bookingCode ? String(item.bookingCode).toUpperCase() : "";
    if (item && code && !removedBooking(item) && !removedCodes.has(code)) items.push(item);
  }
  return items;
}
async function handle(request) {
  const blobs = store();
  if (request.method === "POST") {
    let input2;
    try {
      input2 = await request.json();
    } catch {
      return json(400, { error: "\u0110\u01A1n kh\xF4ng h\u1EE3p l\u1EC7." });
    }
    if (input2 && input2.kind === "subscribe") {
      const email = clip(input2.email, 120).toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json(400, { error: "Email ch\u01B0a \u0111\xFAng." });
      const key3 = `subscriber/${encodeURIComponent(email)}`;
      const existing2 = await blobs.get(key3, { type: "json" });
      if (!existing2) await blobs.setJSON(key3, { email, createdAt: (/* @__PURE__ */ new Date()).toISOString() });
      return json(200, { ok: true });
    }
    const record = assessBooking(input2);
    if (!record) return json(400, { error: "\u0110\u01A1n kh\xF4ng h\u1EE3p l\u1EC7." });
    const key2 = bookingKey(record.bookingCode);
    const removed = await readJSON(blobs, deletedKey(record.bookingCode));
    if (removed) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng t\u1EA1o l\u1EA1i." });
    const existing = await readJSON(blobs, key2);
    if (removedBooking(existing)) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng t\u1EA1o l\u1EA1i." });
    if (existing) {
      if (!sameBooking(existing, record)) return json(409, { error: "M\xE3 \u0111\u1EB7t ch\u1ED7 n\xE0y \u0111\xE3 c\xF3. Kh\xF4ng ghi \u0111\xE8 \u0111\u01A1n c\u0169." });
      return json(200, { ok: true });
    }
    const write = await blobs.setJSON(key2, record, { onlyIfNew: true });
    if (!write.modified) {
      const winner = await readJSON(blobs, key2);
      if (removedBooking(winner)) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng t\u1EA1o l\u1EA1i." });
      if (winner && sameBooking(winner, record)) return json(200, { ok: true });
      return json(409, { error: "M\xE3 \u0111\u1EB7t ch\u1ED7 n\xE0y v\u1EEBa \u0111\u01B0\u1EE3c d\xF9ng. H\xE3y \u0111\u1EB7t l\u1EA1i \u0111\u1EC3 l\u1EA5y m\xE3 m\u1EDBi." });
    }
    return json(200, { ok: true });
  }
  if (!process.env.ADMIN_PASSWORD) return json(503, { error: "Ch\u01B0a c\u1EA5u h\xECnh m\u1EADt kh\u1EA9u qu\u1EA3n l\xFD." });
  if (!authorized(request)) return json(401, { error: "M\u1EADt kh\u1EA9u ch\u01B0a \u0111\xFAng." });
  if (request.method === "GET") {
    const items = await readItems(blobs);
    items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    const subscribers = await readSubscribers(blobs);
    return json(200, { items, subscribers });
  }
  let input = {};
  try {
    input = await request.json();
  } catch {
    return json(400, { error: "Kh\xF4ng \u0111\u1ECDc \u0111\u01B0\u1EE3c y\xEAu c\u1EA7u." });
  }
  const bookingCode = clip(input.bookingCode, 16).toUpperCase();
  const key = bookingKey(bookingCode);
  if (request.method === "PATCH") {
    if (!STATUSES.has(input.status)) return json(400, { error: "Tr\u1EA1ng th\xE1i kh\xF4ng h\u1EE3p l\u1EC7." });
    if (await readJSON(blobs, deletedKey(bookingCode))) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng c\u1EADp nh\u1EADt." });
    const current = await readRecord(blobs, key);
    if (!current?.data || removedBooking(current.data)) return json(404, { error: "Kh\xF4ng th\u1EA5y \u0111\u01A1n n\xE0y." });
    if (await readJSON(blobs, deletedKey(bookingCode))) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng c\u1EADp nh\u1EADt." });
    if (!current.etag) return json(409, { error: "\u0110\u01A1n v\u1EEBa thay \u0111\u1ED5i. H\xE3y t\u1EA3i l\u1EA1i." });
    const write = await blobs.setJSON(key, { ...current.data, status: input.status }, { onlyIfMatch: current.etag });
    if (!write.modified) {
      const winner = await readJSON(blobs, key);
      const gone = await readJSON(blobs, deletedKey(bookingCode));
      if (!winner || removedBooking(winner) || gone) return json(409, { error: "\u0110\u01A1n n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c x\xF3a. Kh\xF4ng c\u1EADp nh\u1EADt." });
      return json(409, { error: "\u0110\u01A1n v\u1EEBa thay \u0111\u1ED5i. H\xE3y t\u1EA3i l\u1EA1i." });
    }
    return json(200, { ok: true });
  }
  if (request.method === "DELETE") {
    if (!/^HE-\d{6}$/.test(bookingCode)) return json(400, { error: "M\xE3 kh\xF4ng h\u1EE3p l\u1EC7." });
    const deletedAt = (/* @__PURE__ */ new Date()).toISOString();
    await blobs.setJSON(deletedKey(bookingCode), { bookingCode, deletedAt });
    await blobs.setJSON(key, { bookingCode, status: "deleted", deletedAt });
    return json(200, { ok: true });
  }
  return json(405, { error: "Kh\xF4ng h\u1ED7 tr\u1EE3." });
}
var bookings_default = async (request) => {
  try {
    return await handle(request);
  } catch (error) {
    console.error(error);
    return json(500, { error: "Kh\xF4ng l\u01B0u \u0111\u01B0\u1EE3c \u0111\u01A1n. Th\u1EED l\u1EA1i sau gi\xE2y l\xE1t." });
  }
};
export {
  assessBooking,
  bookings_default as default
};
